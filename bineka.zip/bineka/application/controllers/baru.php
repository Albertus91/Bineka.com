<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class baru extends CI_Controller {

	public function index(){
		$this->load->model('modelhome');
		// echo "Hello word";
        $datamahasiswa = $this->modelhome->read('mahasiswa');
        
			$data2 = array(
				'data' => $datamahasiswa
			);
	
			$this->load->view('Home', $data2);

	}

	public function baca_form(){
		$this->load->view('form_tambah');
	}

	public function tambah_data(){
		$this->load->model('modelhome');
		$datainputan = array(
			'nama' => $this->input->post('nama'),
			'nim' => $this->input->post('nim'),
			'email' => $this->input->post('email'),
			'kontak' => $this->input->post('kontak'),
			'alamat' => $this->input->post('alamat')
		);
		$this->modelhome->created('mahasiswa', $datainputan);
		redirect(base_url(), 'refresh');
	}
	
	public function hapus_data($penunjuk){
		$datapenunjuk = array(
			'id' => $penunjuk
		);
		$this->load->model('modelhome');
		$this->modelhome->delete('mahasiswa', $datapenunjuk);
		redirect(base_url(), 'refresh');

	}

	public function ambil_nomor($penunjuk){
		$datapenunjuk = array(
			'id' => $penunjuk
		);
		
		$this->load->model('modelhome');
        $datamahasiswa = $this->modelhome->read_khusus('mahasiswa', $datapenunjuk);
			$data2 = array(
				'data' => $datamahasiswa
		);
		$this->load->view('form_edit', $data2);

	}

	public function update_data(){
		$datainputan = array(
			'nama' => $this->input->post('nama'),
			'nim' => $this->input->post('nim'),
			'email' => $this->input->post('email'),
			'kontak' => $this->input->post('kontak'),
			'alamat' => $this->input->post('alamat')
		);
		$datapenunjuk = array(
			'id' => $this->input->post('id')
		);
		$this->load->model('modelhome');
		$datamahasiswa = $this->modelhome->perbarui('mahasiswa', $datainputan, $datapenunjuk);
		redirect(base_url(), 'refresh');
	}
        
        // foreach($datamahasiswa as $ma){
        //     $gambar = $ma['gambar']."<br><br><br>";
        //     echo "nama: ".$ma['nama']."<br>";
        //     echo "nim: ".$ma['nim']."<br>";
        //     echo "email: ".$ma['email']."<br>";
        //     echo "kontak: ".$ma['kontak']."<br>";
        //     echo "alamat: ".$ma['alamat']."<br><br><br>";
	// public function adalah()
	// {
	// 	// echo "Hello World";
	// 	$this->load->view('home');
	// }
	// public function fokus($nama)
	// {
	// 	// echo "Selamat datang Tuan ".$nama;
	// 	$data1 = array(
	// 		'nama' => $nama
	// 	);

	// 	$this->load->view('Home', $data1);
	// }


}


