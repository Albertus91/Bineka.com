<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h2>Halo dunia</h2>
    <h3>latihan code igniter</h3>
    <a href="<?php echo base_url(). "index.php/baru/baca_form"; ?>">Tambah Data</a><br><br>
    <table border='1'>
        <tr>
            <td>Nama</td>
            <td>Nim</td>
            <td>Email</td>
            <td>Kontak</td>
            <td>Alamat</td>
            <td>Aksi</td>
        </tr>
        <?php
            foreach($data as $ma){
        ?>
            <tr>
                <td><?php echo $ma['nama']; ?></td>
                <td><?php echo $ma['nim']; ?></td>
                <td><?php echo $ma['email']; ?></td>
                <td><?php echo $ma['kontak']; ?></td>
                <td><?php echo $ma['alamat']; ?></td>
                <td>
                    <a href="<?php echo base_url(). "index.php/baru/hapus_data/".$ma['id']; ?>">Delete</a> | 
                    <a href="<?php echo base_url(). "index.php/baru/ambil_nomor/".$ma['id']; ?>">Edit</a>
                </td>
            </tr>

        <?php } ?>
    </table>
    
</body>
</html>