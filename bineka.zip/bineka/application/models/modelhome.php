<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class modelhome extends CI_Model {

    public function read($tabel){
        $databaru = $this->db->get($tabel);
        return $databaru->result_array();
    }
    public function created($tabel, $data){
        $databaru = $this->db->insert($tabel, $data);
        return $databaru;
    }
    public function perbarui($tabel, $data, $where){
        $databaru = $this->db->update($tabel, $data, $where);
        return $databaru;
    }
    public function read_khusus($tabel, $where){
        $databaru = $this->db->get_where($tabel, $where);
        return $databaru->result_array();
    }
    public function delete($tabel, $where){
        $databaru = $this->db->delete($tabel, $where);
        return $databaru;
    }


}
